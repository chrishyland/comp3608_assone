'''
About: COMP3608 Assignment 1
Author: Charles Christopher Hyland

----------------------------------------------------------------------------------------------------
This is testing purposes and used to modularise the code.
----------------------------------------------------------------------------------------------------

'''
import sys
from game_setup import * # Contains all functions to set up game
from game_actions import *
from state import *
from minmax import *

def main():

	initial_state = start_game()
	board = create_board(initial_state['board_state'])

	# Create game tree.
	root = create_tree(initial_state['depth'], board, initial_state['player'])
	#print(min_max(root, initial_state['depth'], True, root.player))
	print(move_make(root, initial_state['depth'], True, root.player)[1].move[1])
	
	print(countNodes(root)) # Add seven since need to check root's children
	


if __name__ == '__main__':
	main()